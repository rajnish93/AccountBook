jQuery(document).ready(function () {
  jQuery().invoice({
    //addRow : ".addRow", delete : ".delete",
    parentClass: ".add_fields",
    batch: ".batch",
    price: ".price",
    qty: ".qty",
    igst: ".igst",
    cgst: ".cgst",
    sgst: ".sgst",
    total: ".total",
    subigst: ".subigst",
    subcgst: ".subcgst",
    subsgst: ".subsgst",
    totaligst: "#totaligst",
    totalcgst: "#totalcgst",
    totalsgst: "#totalsgst",
    totalQty: "#totalQty",
    subtotal: "#subtotal",
    discount: "#discount",
    shipping: "#shipping",
    grandTotal: "#grandTotal",
    billAmount: '#billAmount',
    //wo:"#wo"

  });
});
