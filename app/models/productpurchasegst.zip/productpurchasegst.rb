class Productpurchasegst < ApplicationRecord
  belongs_to :chartaccount
  belongs_to :supplier
  belongs_to :employee
  has_many :purchproditemgsts, dependent: :destroy
  accepts_nested_attributes_for :purchproditemgsts, allow_destroy: true, reject_if: proc { |att| att['rkpurchprodname'].blank? }
end
